import json
import boto3
import snowflake.connector
from datetime import datetime
import csv
import os

# Initialize the S3 and SES clients
s3 = boto3.client('s3')
ses = boto3.client('ses')

def write_to_snowflake(data):
    # Replace with your Snowflake connection details
    conn = snowflake.connector.connect(
        user='muskan',
        password='mus@_pat_we@K0r',
        account='rwevwyj-ddb43031',
        warehouse='COMPUTE_WH',
        database='SNOWFLAKE_PYHTON',
        schema='LOGS_SCHEMA'
    )
    
    try:
        cursor = conn.cursor()
        # Replace 'YOUR_TABLE' with your actual Snowflake table
        cursor.execute("""
            INSERT INTO S3_UPLOAD_EVENTS (filename, uploader, event_time, lambda_time, is_successful, error_message)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, data)
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def write_error_to_snowflake(error_data):
    conn = snowflake.connector.connect(
        user='muskan',
        password='mus@_pat_we@K0r',
        account='rwevwyj-ddb43031',
        warehouse='COMPUTE_WH',
        database='SNOWFLAKE_PYHTON',
        schema='LOGS_SCHEMA'
    )
    
    try:
        cursor = conn.cursor()
        # Replace 'YOUR_ERROR_TABLE' with your actual Snowflake table for errors
        cursor.execute("""
            INSERT INTO S3_UPLOAD_ERRORS (filename, uploader, event_time, lambda_time, error_message)
            VALUES (%s, %s, %s, %s, %s)
        """, error_data)
        conn.commit()
    finally:
        cursor.close()
        conn.close()

def send_email(subject, body, recipients):
    ses.send_email(
        Source='home.sayeed.pc@gmail.com',
        Destination={
            'ToAddresses': recipients
        },
        Message={
            'Subject': {
                'Data': subject
            },
            'Body': {
                'Text': {
                    'Data': body
                }
            }
        }
    )

def lambda_handler(event, context):
    try:
        # Extract details from the event
        bucket_name = event['Records'][0]['s3']['bucket']['name']
        object_key = event['Records'][0]['s3']['object']['key']
        filename = object_key.split('/')[-1]
        event_time = event['Records'][0]['eventTime']
        uploader = event['Records'][0]['userIdentity']['principalId']
        lambda_time = datetime.utcnow().isoformat()
        
        # Prepare data for Snowflake
        data = (filename, uploader, event_time, lambda_time, True, None)
        write_to_snowflake(data)

        return {
            'statusCode': 200,
            'body': json.dumps('S3 event processed and logged successfully!')
        }

    except Exception as e:
        # Log error to CSV
        error_message = str(e)
        csv_filename = f"error_log_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.csv"
        csv_file_path = f"/tmp/{csv_filename}"

        with open(csv_file_path, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["filename", "uploader", "event_time", "lambda_time", "is_successful", "error_message"])
            writer.writerow([filename, uploader, event_time, lambda_time, False, error_message])
        
        # Upload the CSV to S3
        s3.upload_file(csv_file_path, bucket_name, f"errors/{csv_filename}")
        
        # Send an email notification
        send_email(
            subject="S3 Event Processing Failure",
            body=f"An error occurred while processing the file {filename}.\n\nError: {error_message}",
            recipients=["home.sayeed.pc@gmail.com", "home.sayeed.pc+py@gmail.com"]
        )
        
        # Write the error data to Snowflake
        error_data = (filename, uploader, event_time, lambda_time, False, error_message)
        write_error_to_snowflake(error_data)

        return {
            'statusCode': 500,
            'body': json.dumps(f"Error processing S3 event: {error_message}")
        }
